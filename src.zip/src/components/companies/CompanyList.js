import React, { Component } from 'react';
import Company from './company/company';

const companyList=props=>{
    let companies = props.companies.map( company=>{
        if(company.date === '01-03-2021')
            return <Company addToWatch={props.add} key={company.id} company={company}/>
    })
    return(
        <div className="d-flex justify-content-between">
            {companies}
        </div>
    )
}
export default companyList;