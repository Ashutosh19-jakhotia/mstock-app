import React, {useState} from 'react';
import Perf from './perftable'
import $ from 'jquery';
const Performance = props => {
    let companies = props.companies;
    
        let optionItems = companies.map((company) => {
            
            if(company.date == '01-03-2021') {
                return <option key={company.name}>{company.name}</option>
            }
                
        });
        var i =0 ;
        const [isPerfomed, setIsPerfomed] = useState(0);
        const [comps, setComps]= useState(null);
        let dates = companies.map((company)=>{
            
            if(i < companies.length){
                
                i = i+3;
                return <option key={company.date}>{company.date}</option>
                
            }
                
        });
        console.log(i);
        
        function perHandler(){
            let c=[];
            let selectedcompany1 = $("#selectedcompany1").val();
            let selectedcompany2 = $("#selectedcompany2").val();
            let date2 = $("#date2").val();
            companies.map((company) =>{
                if(company.name === selectedcompany1 || company.name === selectedcompany2){
                    if(company.date <= date2){
                        c.push(company);
                    }
                }
            })
            setIsPerfomed(isPerfomed + 1);
            setComps(c);
            console.log(c)
        }

       
    return(
        <div>
            <h3>Compare Potential Companies</h3>
            <h5>Make smart investment decision</h5>
            
            <table class="table">
                <tr>
                    <td>Select company 1 
                        <br></br> 
                        <select id="selectedcompany1" name="selectedcompany1">
                            {optionItems}
                        </select>
                    </td> 
                    <td>Select company 2 
                        <br></br> 
                        <select id="selectedcompany2" name="selectedcompany2">
                            {optionItems}
                        </select>
                    </td> 
                </tr>
                <br></br>
                <tr>
                    <td>From Date  
                        <br></br> 
                        <select id="date1" name="date1">
                            {dates}
                        </select>
                    </td> 
                    <td>Select company 2 
                        <br></br> 
                        <select id="date2" name="date2">
                            {dates}
                        </select>
                    </td> 
                </tr>
                <tr><td><button  class="btn btn-block bg-primary" onClick={() => perHandler()}>fetch Details</button></td><td></td></tr>
            </table>
            
            <div>
              
            {console.log(comps) } {isPerfomed > 0 ? <Perf companies={comps}/> : console.log("not called")}
            
            </div>
        </div>
        
    )
}
export default Performance;